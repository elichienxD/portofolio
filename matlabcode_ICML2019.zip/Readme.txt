function [ result ] = Supportestimation( N,k,c0,nC,option )
% Input: 
%        N : a histogram of your samples. Should be a 1-dim vector with
%        positive entries. No zeros are allowed!

%        k : the parameter such that the minimum non zero probability of
%        a alphabet for underlying distribution is lower bounded by 1/k. By
%        default set it to be sum(N).

%        c0 : the parameter to determine the degree of the polynomial. By
%        default set it to be 0.558.

%        nC : number of grid points. For n = 10^6 it is sufficient to set it to be 1000. nC = sqrt(n) would be a rule of thumb, but maybe a much small nC will %	 also works.

%        option is an parameter to decide which loss function would you
%        like to optimize. Set option = 0 for RWC estimator and
%        option = 1 for RWC-S.
%
% Output: 
%        result is the estimated support.


%The main function is Supportestimation( N,k,c0,nC,option ). To use this function please first unzip all the .m files to your directory. The code is tested on %Matlab R2016b so it should also work for the later versions. 

