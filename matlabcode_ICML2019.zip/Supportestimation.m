function [ result ] = Supportestimation( N,k,c0,nC,option )
% Input: 
%        N : a histogram of your samples. Should be a 1-dim vector with
%        positive entries. No zeros are allowed!

%        k : the parameter such that the minimum non zero probability of
%        a alphabet for underlying distribution is lower bounded by 1/k. 
%        By default set it to be sum(N).

%        c0 : the parameter to determine the degree of the polynomial. By
%        default set it to be 0.558.

%        nC : number of grid points. For n = 10^6 it is sufficient to set 
%        it to be 1000. nC = sqrt(n) would be a rule of thumb, but maybe a  
%	     much small nC will also works.

%        option is an parameter to decide which loss function would you
%        like to optimize. Set option = 0 for RWC estimator and
%        option = 1 for RWC-S.
%
% Output: 
%        result is the estimated support.


% The main function is Supportestimation( N,k,c0,nC,option ).  
% To use this function please first unzip all the .m files to your directory. 
% The code is tested on %Matlab R2016b so it should also work for the later versions.


n = sum(N);
S_naive = size(N,1);
L = floor(c0*log(k));

if option == 0
    [ a_LPquad,~ ] = LPwQuadconstr( n,k,c0,0,nC,k );
    a_LPquad = [-1;a_LPquad];
elseif option == 1
    [ a_LPquad,~ ] = LPwQuadconstr( n,k,c0,0,nC,S_naive );
    a_LPquad = [-1;a_LPquad];
else 
    disp('invalid option value. Please read the comments for this function')
    result = -1;
    return;
end

Input = N(N<L+1);
Input_c = N(N>L);

[ gL_LPquad ] = getgL2( a_LPquad,L );
result = sum(gL_LPquad(Input+1))+length(Input_c);
end

